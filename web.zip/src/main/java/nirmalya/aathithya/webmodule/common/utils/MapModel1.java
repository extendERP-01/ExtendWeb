package nirmalya.aathithya.webmodule.common.utils;

public class MapModel1 {
	private String name;
	
	private Double y;

	public MapModel1() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getY() {
		return y;
	}

	public void setY(Double y) {
		this.y = y;
	}

	
	
}
