package nirmalya.aathithya.webmodule.common.utils;

public class MapModel {
	private String name;
	private Integer y;
	private Double a;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getY() {
		return y;
	}
	public void setY(Integer y) {
		this.y = y;
	}
	public Double getA() {
		return a;
	}
	public void setA(Double a) {
		this.a = a;
	}
	
	
}
