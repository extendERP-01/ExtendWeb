package nirmalya.aathithya.webmodule.recruitment.model;

public class AddRecruitentModel {

	public AddRecruitentModel() {
		super();
		// TODO Auto-generated constructor stub
	}

}
